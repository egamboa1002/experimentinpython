﻿using System;
using System.Windows.Forms;

namespace FINAL_EXAM_PROJECT
{
    public partial class CurrencyConverter : Form
    {
        public CurrencyConverter()
        {
            InitializeComponent();
        }

        private void CurrencyConverter_Load(object sender, EventArgs e)
        {
            cmbFrom.Items.Clear();
            cmbTo.Items.Clear();

            cmbFrom.Items.Add("USD");
            cmbFrom.Items.Add("PHP");
            cmbFrom.Items.Add("YEN");

            cmbTo.Items.Add("USD");
            cmbTo.Items.Add("PHP");
            cmbTo.Items.Add("YEN");

            cmbFrom.SelectedIndex = 0;
            cmbTo.SelectedIndex = 1;
        }


        private void btnConvert_Click(object sender, EventArgs e)
        {
            double amount;

            if (!double.TryParse(txtInput.Text, out amount))
            {
                MessageBox.Show("Enter a valid amount.");
                return;
            }

            string from = cmbFrom.Text.Trim();
            string to = cmbTo.Text.Trim();

            double usdToPhp = 61.758;
            double usdToYen = 162.43;

            double usdAmount = 0;
            double result = 0;
            if (from == "USD")
            {
                usdAmount = amount;
            }
            else if (from == "PHP")
            {
                usdAmount = amount / usdToPhp;
            }
            else if (from == "YEN")
            {
                usdAmount = amount / usdToYen;
            }
            if (to == "USD")
            {
                result = usdAmount;
            }
            else if (to == "PHP")
            {
                result = usdAmount * usdToPhp;
            }
            else if (to == "YEN")
            {
                result = usdAmount * usdToYen;
            }


            txtAmount.Text = result.ToString("F2");
        }


        private void btnCurrencyClear_Click(object sender, EventArgs e)
        {
            txtAmount.Clear();
            txtAmount.Clear();
            cmbFrom.SelectedIndex = 0;
            cmbTo.SelectedIndex = 1;
        }


        private void btnBack_Click(object sender, EventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Show();
            this.Hide();
        }
    }
}
