﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FINAL_EXAM_PROJECT
{
    public partial class TemperatureConverter : Form
    {
        public TemperatureConverter()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void cmbFrom_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void TemperatureConverter_Load(object sender, EventArgs e)
        {
            cmbFrom.Items.Add("Celsius");
            cmbFrom.Items.Add("Fahrenheit");
            cmbFrom.Items.Add("Kelvin");

            cmbTo.Items.Add("Celsius");
            cmbTo.Items.Add("Fahrenheit");
            cmbTo.Items.Add("Kelvin");

            cmbFrom.SelectedIndex = 0;
            cmbTo.SelectedIndex = 1;
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            double temp;

            if (!double.TryParse(txtInput.Text, out temp))
            {
                MessageBox.Show("Please enter a valid temperature.");
                return;
            }

            string from = cmbFrom.Text.Trim();
            string to = cmbTo.Text.Trim();

            double result = 0;

            if (from == "Celsius" && to == "Fahrenheit")
            {
                result = (temp * 9 / 5) + 32;
            }
            else if (from == "Celsius" && to == "Kelvin")
            {
                result = temp + 273.15;
            }
            else if (from == "Fahrenheit" && to == "Celsius")
            {
                result = (temp - 32) * 5 / 9;
            }
            else if (from == "Fahrenheit" && to == "Kelvin")
            {
                result = ((temp - 32) * 5 / 9) + 273.15;
            }
            else if (from == "Kelvin" && to == "Celsius")
            {
                result = temp - 273.15;
            }
            else if (from == "Kelvin" && to == "Fahrenheit")
            {
                result = ((temp - 273.15) * 9 / 5) + 32;
            }
            else
            {
                MessageBox.Show("Please select different conversion types.");
                return;
            }

            txtResult.Text = result.ToString("F2");
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Show();
            this.Hide();
        }
    }
}
