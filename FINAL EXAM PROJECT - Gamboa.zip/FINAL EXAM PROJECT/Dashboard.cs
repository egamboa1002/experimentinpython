﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FINAL_EXAM_PROJECT
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Form1 login = new Form1();
            login.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void btnCalculator_Click(object sender, EventArgs e)
        {
            Calculator calc = new Calculator();
            calc.Show();
            this.Hide();
        }

        private void btnTemperature_Click(object sender, EventArgs e)
        {
            TemperatureConverter temp = new TemperatureConverter();
            temp.Show();
            this.Hide();
        }

        private void btnCurrency_Click(object sender, EventArgs e)
        {
            CurrencyConverter currency = new CurrencyConverter();
            currency.Show();
            this.Hide();
        }

        private void btnVigenere_Click(object sender, EventArgs e)
        {
            VigenereCipher vigenere = new VigenereCipher();
            vigenere.Show();
            this.Hide();
        }
    }
}
