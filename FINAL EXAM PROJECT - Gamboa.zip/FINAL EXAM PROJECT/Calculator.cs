﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FINAL_EXAM_PROJECT
{
    public partial class Calculator : Form
    {
        double firstNumber = 0;
        string operation = "";
        bool newNumber = true;
        public Calculator()
        {
            InitializeComponent();
        }

        private void NumberButton_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            if (newNumber)
            {
                newNumber = false;
            }

            txtDisplay.Text += btn.Text;
        }
        private void OperationButton_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            firstNumber = Convert.ToDouble(txtDisplay.Text);

            operation = btn.Text;

            txtDisplay.Text += operation;

            newNumber = true;
        }
            private void btnEquals_Click(object sender, EventArgs e)
        {
            string expression = txtDisplay.Text;

            double secondNumber = 0;
            double result = 0;

            if (operation == "+")
            {
                secondNumber = Convert.ToDouble(expression.Split('+')[1]);
                result = firstNumber + secondNumber;
            }
            else if (operation == "-")
            {
                secondNumber = Convert.ToDouble(expression.Split('-')[1]);
                result = firstNumber - secondNumber;
            }
            else if (operation == "*")
            {
                secondNumber = Convert.ToDouble(expression.Split('*')[1]);
                result = firstNumber * secondNumber;
            }
            else if (operation == "/")
            {
                secondNumber = Convert.ToDouble(expression.Split('/')[1]);

                if (secondNumber == 0)
                {
                    MessageBox.Show("Cannot divide by zero.");
                    return;
                }

                result = firstNumber / secondNumber;
            }

            txtDisplay.Text = result.ToString();

            newNumber = true;
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = "";
            firstNumber = 0;
            operation = "";
            newNumber = true;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Show();
            this.Hide();
        }
    }

}


