﻿using System.Data.SqlClient;

public class DatabaseConnection
{
    public static SqlConnection GetConnection()
    {
        string connectionString = @"Server=localhost;Database=LoginSystem;Trusted_Connection=True;TrustServerCertificate=True;";

        return new SqlConnection(connectionString);
    }
}