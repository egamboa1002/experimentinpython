﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FINAL_EXAM_PROJECT
{
    public partial class Form1 : Form
    {
        int attempts = 3;

        SqlConnection con = DatabaseConnection.GetConnection();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = '*';
            lblAttempts.Text = "Attempts Remaining: 3";
        }

        private void chkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShowPassword.Checked)
            {
                txtPassword.PasswordChar = '\0';
            }
            else
            {
                txtPassword.PasswordChar = '*';
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "")
            {
                MessageBox.Show("Please enter your username.");
                txtUsername.Focus();
                return;
            }

            if (txtPassword.Text == "")
            {
                MessageBox.Show("Please enter your password.");
                txtPassword.Focus();
                return;
            }

            try
            {
                con.Open();

                string query = "SELECT * FROM Users WHERE Username=@username AND Password=@password";

                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@username", txtUsername.Text);
                cmd.Parameters.AddWithValue("@password", txtPassword.Text);

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    MessageBox.Show("Login Successful!");
                    Dashboard dashboard = new Dashboard();
                    dashboard.Show();

                    this.Hide();
                }
                else
                {
                    attempts--;

                    lblAttempts.Text = "Attempts Remaining: " + attempts;

                    MessageBox.Show("Invalid Username or Password.");

                    if (attempts == 0)
                    {
                        MessageBox.Show("You have reached the maximum number of login attempts.");
                        Application.Exit();
                    }
                }

                reader.Close();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            Register register = new Register();
            register.Show();
            this.Hide();
        }
    }
}
