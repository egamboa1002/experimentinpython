﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FINAL_EXAM_PROJECT
{
    public partial class VigenereCipher : Form
    {
        private string Encrypt(string text, string key)
        {
            string result = "";
            int keyIndex = 0;

            foreach (char c in text)
            {
                if (char.IsLetter(c))
                {
                    char offset = char.IsUpper(c) ? 'A' : 'a';

                    char encrypted = (char)((c - offset +
                        (key[keyIndex % key.Length] - 'A')) % 26 + offset);

                    result += encrypted;

                    keyIndex++;
                }
                else
                {
                    result += c;
                }
            }

            return result;
        }


        private string Decrypt(string text, string key)
        {
            string result = "";
            int keyIndex = 0;

            foreach (char c in text)
            {
                if (char.IsLetter(c))
                {
                    char offset = char.IsUpper(c) ? 'A' : 'a';

                    char decrypted = (char)((c - offset -
                        (key[keyIndex % key.Length] - 'A') + 26) % 26 + offset);

                    result += decrypted;

                    keyIndex++;
                }
                else
                {
                    result += c;
                }
            }

            return result;
        }
        public VigenereCipher()
        {
            InitializeComponent();
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            string text = txtInput.Text;
            string key = "KEY";

            txtResult.Text = Encrypt(text, key);
        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            string text = txtInput.Text;
            string key = "KEY";

            txtResult.Text = Decrypt(text, key);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Show();
            this.Hide();
        }
    }
}
