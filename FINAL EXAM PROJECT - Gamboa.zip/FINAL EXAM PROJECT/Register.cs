﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FINAL_EXAM_PROJECT
{
    public partial class Register : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=localhost;Initial Catalog=MultiToolDB;Integrated Security=True;TrustServerCertificate=True");
        public Register()
        {
            InitializeComponent();
        }

        private void lblCreateAccount_Click(object sender, EventArgs e)
        {

        }

        private void chkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShowPassword.Checked)
            {
                txtPassword.PasswordChar = '\0';
                txtConfirmPassword.PasswordChar = '\0';
            }
            else
            {
                txtPassword.PasswordChar = '*';
                txtConfirmPassword.PasswordChar = '*';
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Register_Load(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = '*';
            txtConfirmPassword.PasswordChar = '*';
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            SqlConnection con = DatabaseConnection.GetConnection();

            if (txtPassword.Text.Length < 8)
            {
                MessageBox.Show("Password must be at least 8 characters long.");
                txtPassword.Focus();
                return;
            }

            if (!txtPassword.Text.Any(char.IsUpper))
            {
                MessageBox.Show("Password must contain at least one uppercase letter.");
                txtPassword.Focus();
                return;
            }

            try
            {
                con.Open();

                string query = "INSERT INTO Users (Username, Password) VALUES (@username, @password)";

                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@username", txtUsername.Text);
                cmd.Parameters.AddWithValue("@password", txtPassword.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Account Created Successfully!");

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Form1 login = new Form1();
            login.Show();
            this.Hide();
        }
    }
}
